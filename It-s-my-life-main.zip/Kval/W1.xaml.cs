﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kval
{
    /// <summary>
    /// Логика взаимодействия для W1.xaml
    /// </summary>
    public partial class W1 : Window
    {
        public W1()
        {
            InitializeComponent();
            LB1.ItemsSource = Class1.db.Категория.ToList();
        }

        private void t1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var A = LB1.SelectedItem as Категория;
            if(LB1.Items[0] == A)
            {
                Class1.id_cat = "01";
                Fr1.Navigate(new Pg1());
                
            }
            if (LB1.Items[1] == A)
            {
                Class1.id_cat = "02";
                Fr1.Navigate(new Pg1());

            }
            if (LB1.Items[2] == A)
            {
                Class1.id_cat = "03";
                Fr1.Navigate(new Pg1());

            }
            if (LB1.Items[3] == A)
            {
                Class1.id_cat = "04";
                Fr1.Navigate(new Pg1());

            }
        }

    }
}
