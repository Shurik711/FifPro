﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kval
{
    /// <summary>
    /// Логика взаимодействия для W3.xaml
    /// </summary>
    public partial class W3 : Window
    {
        public W3()
        {
            InitializeComponent();

        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win = new MainWindow();
            win.Show();
            Close();
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            string s0, st, s1;
            s0 = "";
            Random rnd = new Random();
            int n;
            st = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            for (int j = 0; j < 9; j++)
            {
                n = rnd.Next(0, 61);
                s1 = st.Substring(n, 1);
                s0 += s1;
                
            }
            pb1.Password = s0;

        }
    }
}
