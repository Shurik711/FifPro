﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kval
{
    /// <summary>
    /// Логика взаимодействия для W1.xaml
    /// </summary>
    public partial class W1 : Window
    {
        public W1()
        {
            InitializeComponent();
        }

        private void t1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Fr1.Navigate(new Pg1());
        }

        private void t2_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Fr1.Navigate(new Pg2());
        }

        private void t3_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Fr1.Navigate(new Pg3());
        }

        private void t4_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Fr1.Navigate(new Pg4());
        }
    }
}
