﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.Xml.Linq;
using System.Data;
using System.IO;

namespace FE
{
    /// <summary>
    /// Логика взаимодействия для Win2.xaml
    /// </summary>
    public partial class Win2 : Window
    {
        public Win2()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            {
                int a = 1;
                int b = 2;
                int c = 3;
                int d = 4;
                int dd = 5;
                int f = 6;
                int g = 7;
                int h = 8;
                int i = 9;
                int j = 0;
                if (one.IsChecked == true)
                {
                    //   Class1.cl1 = a;

                    Class2.cl1 = (01);
                    Class2.cl11 += (200);
                    Class2.cl111 += (a);
                    //        Class1.fcl = Class1.cl1 + Class1.cl0;
                    //        StreamWriter writer = new StreamWriter(@"C:\Users\Shurik\source\repos\FE\Zak\Zak.csv");
                    //      writer.WriteLine("Number");
                    //   Class1.fcl = Class1.cl1 + Class1.cl0;
                    //   StreamWriter writer = new StreamWriter(@"C:\Users\Shurik\source\repos\FE\Zak\01.csv");
                    //   writer.WriteLine("Number");
                    //   writer.WriteLine(Class1.cl1);
                    //   writer.Close();
                }
                if (two.IsChecked == true)
                {
                    Class2.cl2 = (02);
                    Class2.cl22 += (220);
                    Class2.cl222 += (a);
                    //    Class1.cl2 += b;
                    //   Class1.fcl = Class1.cl2 + Class1.cl0;
                    //    StreamWriter writer = new StreamWriter(@"C:\Users\Shurik\source\repos\FE\Zak\02.csv");
                    //    writer.WriteLine("Number");
                    //    writer.WriteLine(Class1.cl2);
                    //    writer.Close();
                }
                if (three.IsChecked == true)
                {
                    Class2.cl3 = (03);
                    Class2.cl33 += (180);
                    Class2.cl333 += (a);
                }
                if (four.IsChecked == true)
                {
                    Class2.cl4 = (04);
                    Class2.cl44 += (200);
                    Class2.cl444 += (a);
                }
                if (five.IsChecked == true)
                {
                    Class2.cl5 = (05);
                    Class2.cl55 += (180);
                    Class2.cl555 += (a);
                }
                if (six.IsChecked == true)
                {
                    Class2.cl6 = (06);
                    Class2.cl66 += (180);
                    Class2.cl666 += (a);
                }
                if (seven.IsChecked == true)
                {
                    Class2.cl7 = (07);
                    Class2.cl77 += (180);
                    Class2.cl777 += (a);
                }
                if (eight.IsChecked == true)
                {
                    Class2.cl8 = (08);
                    Class2.cl88 += (200);
                    Class2.cl888 += (a);
                }
                if (nine.IsChecked == true)
                {
                    Class2.cl9 = (09);
                    Class2.cl99 += (230);
                    Class2.cl999 += (a);
                }
                if (one.IsChecked == true)
                {
                    Class2.cl0 += 0;
                }

                Class2.fcl = Class2.cl1 + -Class2.cl2 + -Class2.cl3 + -Class2.cl4 + -Class2.cl5 + -Class2.cl6 + -Class2.cl7 + -Class2.cl8 + -Class2.cl9 + -Class2.cl0;
                StreamWriter writer = new StreamWriter(@"C:\Users\student\source\repos\FE\Zak\Second.csv");
                writer.WriteLine("Number/Total/Quantity");
                writer.WriteLine(Class2.cl1 + ";" + Class2.cl2 + ";" + Class2.cl3 + ";" + Class2.cl4 + ";" + Class2.cl5 + ";" + Class2.cl6 + ";" + Class2.cl7 + ";" + Class2.cl8 + ";" + Class2.cl9);
                writer.WriteLine(Class2.cl11 + ";" + Class2.cl22 + ";" + Class2.cl33 + ";" + Class2.cl44 + ";" + Class2.cl55 + ";" + Class2.cl66 + ";" + Class2.cl77 + ";" + Class2.cl88 + ";" + Class2.cl99);
                writer.WriteLine(Class2.cl111 + ";" + Class2.cl222 + ";" + Class2.cl333 + ";" + Class2.cl444 + ";" + Class2.cl555 + ";" + Class2.cl666 + ";" + Class2.cl777 + ";" + Class2.cl888 + ";" + Class2.cl999);
                writer.Close();
            }
        }
    }
}
